#include "LinkedList.hpp"

using namespace std;

LinkedList::LinkedList(){
        head = NULL;
    }

LinkedList::~LinkedList(){
	Node* crawler;
	while(head!=nullptr){
		crawler = head->next;
		delete head;
		head = crawler;
	}
}

// Add a new Node to the list
void LinkedList::insert(Node* prev, int newKey){

    //Check if head is Null i.e list is empty
    if(head == NULL){
        head = new Node;
        head->key = newKey;
        head->next = NULL;
    }

        // if list is not empty, look for prev and append our Node there
    else if(prev == NULL)
    {
        Node* newNode = new Node;
        newNode->key = newKey;
        newNode->next = head;
        head = newNode;
    }

    else{

        Node* newNode = new Node;
        newNode->key = newKey;
        newNode->next = prev->next;
        prev->next = newNode;

    }
}



// Building list
void LinkedList::loadList(int* keys , int length) {

    insert(NULL, keys[0]);

    Node* prev = head;

    for(int i = 1; i < length; i++)
    {
        insert(prev, keys[i]);
        prev = prev->next;
    }

}

// Print the keys in your list
void LinkedList::printList(){
    Node* temp = head;

    while(temp->next != NULL){
        cout<< temp->key <<" -> ";
        temp = temp->next;
    }

    cout<<temp->key<<" -> NULL"<<endl;
}

///////////////////////////////////////////////////////////////
// TODO : Complete the following function
void LinkedList::removeNthFromEnd(int n){

    int listSize = 1;
    Node* temp = head;

    //This loop finds the size of the list
    while (temp->next != NULL) {
        listSize++;
        temp = temp->next;
    }

    if (n > listSize || n < 1) {
        return;
    }

    //Finds the index to delete in reference to the front of the list
    int indexToDelete = listSize - (n-1);

    //Edge case for if n is the same length as the list
    if (indexToDelete == 1) {
        temp = head;
        head = head->next;
        delete temp;
        return;
    }

    temp = head->next;
    Node* prev = head;
    //Iterate through the list the appropriate amount of times to set temp to the toBeDeleted index and prev to the previous index
    for (int i = 1; i < indexToDelete - 1; i++) {
        temp = temp->next;
        prev = prev->next;
    }

    //Reroute the list around the deleted value and then delete it
    prev->next = temp->next;
    delete temp;
}

